module SurveyorHelper
  include Surveyor::Helpers::SurveyorHelperMethods
end
